﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EmployeeManagement_API.Data;
using EmployeeManagement_API.Models;

namespace EmployeeManagement_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentRolesController : ControllerBase
    {
        private readonly EmployeeDBContext _context;

        public PaymentRolesController(EmployeeDBContext context)
        {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PaymentRole>>> GetPaymentRoles()
        {
            try
            {
                return Ok(await _context.PaymentRoles.ToListAsync());
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<PaymentRole>> GetPaymentRole(int id)
        {
            try
            {
                var paymentRole = await _context.PaymentRoles.FindAsync(id);

                if (paymentRole == null)
                {
                    return NotFound();
                }

                return paymentRole;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPaymentRole(int id, PaymentRole paymentRole)
        {
            if (id != paymentRole.SerialNo)
            {
                return BadRequest();
            }

            _context.Entry(paymentRole).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PaymentRoleExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }
        [HttpPost]
        public async Task<ActionResult<PaymentRole>> PostPaymentRole(PaymentRole paymentRole)
        {
            try
            {
                _context.PaymentRoles.Add(paymentRole);
                await _context.SaveChangesAsync();

                return CreatedAtAction("GetPaymentRole", new { id = paymentRole.SerialNo }, paymentRole);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult<PaymentRole>> DeletePaymentRole(int id)
        {try
            {
                var paymentRole = await _context.PaymentRoles.FindAsync(id);
                if (paymentRole == null)
                {
                    return NotFound();
                }
                _context.PaymentRoles.Remove(paymentRole);
                await _context.SaveChangesAsync();
                return paymentRole;
            }
            catch (Exception ex) 
            { 
                throw ex; 
            } 
        }

        private bool PaymentRoleExists(int id)
        {
            return _context.PaymentRoles.Any(e => e.SerialNo == id);
        }
    }
}
