﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement_API.Models
{
    public class PaymentRole
    {
        [Key]
        public int SerialNo { get; set; }
        public string Designation { get; set; }
        public int Salary { get; set; }
        public string Hike { get; set; }

    }
}
