﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement_API.Models
{
    public class Login
    {
        public String Email { get; set; }
        public String Pwd { get; set; }
    }
}
